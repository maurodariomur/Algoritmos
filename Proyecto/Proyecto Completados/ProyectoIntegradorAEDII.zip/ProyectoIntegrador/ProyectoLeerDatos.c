#include<stdio.h>
#include<stdbool.h>
#include<stdlib.h>
#include<locale.h>
#include<string.h>

//declaracion de constantes
#define NUMEROS 5

//declaracion de tipo de Dato
typedef float tCalculos1[NUMEROS];
typedef float tCalculos2[NUMEROS];
typedef float tResultados[NUMEROS];

//declaracion de tipo de estructura
typedef struct{
	tCalculos1 calculos1;
	tCalculos2 calculos2;
	tResultados resultados;
	char nombre[15];
	int edad;
	int frente;
	int final;
}tr_jugadores;

tr_jugadores vr_jugadores; /*declaracion variable de tipo registro*/
FILE * vf_jugadores;/*declaracion variable de tipo fichero*/

//declaracion del prototipado general
void inicializarCola();
void iniciarProcesoLectura();
void leerRegistroLectura();
void procesarRegistroParticipantes();
void finalizarProcesoLectura();

//declaracion del prototipado de consignas
void seleccionEnMenu();
void mostrarNumCargados();
void mostrarSumaNumeros();
void mostrarRestaNumeros();
bool colaVacia(tr_jugadores);
bool colaLlena(tr_jugadores);

//declaracion variables globales
char opcion;
float num1,num2,resultados;

int main(){
	setlocale(LC_ALL,"spanish");
	inicializarCola();
	iniciarProcesoLectura();
 	leerRegistroLectura();
	procesarRegistroParticipantes();
	finalizarProcesoLectura();
	return 0;
}

void inicializarCola(){
	vr_jugadores.frente=-1;
	vr_jugadores.final=-1;
}

void iniciarProcesoLectura(){
	vf_jugadores = fopen("elMundoDeLasMates","rb");
	printf("\n Registros del Archivo\n" );
}

void leerRegistroLectura(){
	fread(&vr_jugadores, sizeof(tr_jugadores), 1 , vf_jugadores);
}

void procesarRegistroParticipantes(){
	while(!feof(vf_jugadores)){
		seleccionEnMenu();
		leerRegistroLectura();
	}
}

bool colaVacia(tr_jugadores vr_jugadores){
	return(vr_jugadores.frente==-1 && vr_jugadores.final==-1);
}

bool colaLlena(tr_jugadores vr_jugadores){
	return(vr_jugadores.final==(NUMEROS-1));
}

void seleccionEnMenu(){
	int eleccion;
	printf("\n\t******************************************************");
	printf("\n\t*Participante %s con edad %d, por favor seleccione una Opci�n...\n",vr_jugadores.nombre,vr_jugadores.edad);
	printf("\t******************************************************\n");
	printf("\n\t||1.Sumar Numeros\t||");
	printf("\n\t||2.Restar Numeros\t||");
	printf("\n\t\tSelecci�n: ");
	scanf("%d",&eleccion);
	switch(eleccion){
		case 1:
			mostrarSumaNumeros();	
			break;
		case 2:
			mostrarRestaNumeros();
			break;
	}
}	

void mostrarSumaNumeros(){
	int i;
	float respuesta;
	for(i=vr_jugadores.frente;i<=vr_jugadores.final;i++){
			vr_jugadores.resultados[i]=vr_jugadores.calculos1[i] + vr_jugadores.calculos2[i];
		printf("%.2f + %.2f= ",vr_jugadores.calculos1[i],vr_jugadores.calculos2[i]);
		fflush(stdin);
		scanf("%f",&respuesta);
		
		if(respuesta==vr_jugadores.resultados[i]){
			printf("\n\t!Muy Bien tu respuesta fue correcta...!\n");
		}
		else{
			printf("\n\tSu respuesta fue incorrecta, la respuesta es %.2f...\n",vr_jugadores.resultados[i]);
			printf("\n\t!Practica m�s...!\n");
		}
	}
}

void mostrarRestaNumeros(){
	int i,puntos;
	float respuesta;
	for(i=vr_jugadores.frente;i<=vr_jugadores.final;i++){
			vr_jugadores.resultados[i]=vr_jugadores.calculos1[i]-vr_jugadores.calculos2[i];
		printf("%.2f - %.2f= ",vr_jugadores.calculos1[i],vr_jugadores.calculos2[i]);
		fflush(stdin);
		scanf("%f",&respuesta);
		
		if(respuesta==vr_jugadores.resultados[i]){
			puntos+=1;
			printf("\n\t!Muy Bien tu respuesta fue correcta...!");
		}
		else{
			printf("\n\tSu respuesta fue incorrecta, la respuesta es %.2f...\n",vr_jugadores.resultados[i]);
			printf("\n\t!Practica m�s...!");
		}
	}
}

void finalizarProcesoLectura(){
	fclose(vf_jugadores);
}
