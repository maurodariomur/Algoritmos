#include<stdio.h>
#include<stdbool.h>
#include<stdlib.h>
#include<locale.h>
#include<string.h>

//Declaracion de Constante
#define NUMEROS 5

//declaracion de dato personalizado
typedef float tCalculos1[NUMEROS];
typedef float tCalculos2[NUMEROS];
typedef float tResultados[NUMEROS];

//declaracion Estructura
typedef struct{
	tCalculos1 calculos1;
	tCalculos2 calculos2;
	tResultados resultados;
	char nombre[15];
	int edad;
	int frente;
	int final;
}tr_jugadores;

tr_jugadores vr_jugadores; /*declaracion variable de tipo registro*/
FILE * vf_jugadores;/*declaracion variable de tipo fichero*/

//declaracion del prototipado
void iniciarProceso(); 
void continuarProceso();
void ingresarDatosRegistro();
void grabarRegistroParticipante();
void finalizarProceso();

//declaracion del Prototipado De Funciones Especificas
void moduloAbarcador();
void seleccionEnMenu();
void botInteractivo();
void inicializarCola();
void ingresarDatosParticipante();
void explicacionSuma();
void explicacionResta();
bool colaVacia(tr_jugadores);
bool colaLlena(tr_jugadores);
void colaDeNumeros(float,float);
void eliminarNumeros();
void mostrarCola();
 
//delclaracion de variables globales
char opcion;
float num1,num2,resultados;

int main(){
	setlocale(LC_ALL,"spanish");
	iniciarProceso();
	moduloAbarcador();
	return 0;
}

void continuarProceso(){
	printf("\n\tDesea ingresar Datos: S-N: ");
	fflush(stdin);
	scanf("%c",&opcion);
}

void iniciarProceso(){
/* Se abre un archivo nuevo y se asigna a la variable archivo */
	vf_jugadores = fopen("elMundoDeLasMates", "wb");
	printf("\nArchivo creado con Exito...!\n");
}

void moduloAbarcador(){
	continuarProceso();
	botInteractivo();
	ingresarDatosParticipante();
	inicializarCola();
	while(opcion=='s'|| opcion=='S'){
		seleccionEnMenu();
		continuarProceso();
	}
	finalizarProceso();
	
}

void ingresarDatosParticipante(){ 
	printf("Ingrese Su Nombre participante: ");
	fflush(stdin);
	scanf("%[^\n]s",&vr_jugadores.nombre);
	printf("Ingrese su edad Participante: ");
	scanf("%d",&vr_jugadores.edad);
}

void inicializarCola(){
	vr_jugadores.frente=-1;
	vr_jugadores.final=-1;
	printf("\n\tSe inicializo cola...!\n");
}

void botInteractivo(){
	system("cls");
	printf("\n\t!Hola Soy Bot-Pancho!... BIENVENIDO EL MUNDO DE LAS MATES.\n\tYo sere tu ayudante guiandote con tus elecciones (�w�)...\n");
}

void seleccionEnMenu(){
	int eleccion;
	printf("\n\t\t======================");
	printf("\n\t\tEstas son sus Opciones");
	printf("\n\t\t======================\n");
	printf("\n\t||1.Explicaci�n de la Suma de N�meros\t||");
	printf("\n\t||2.Explicaci�n de la Resta de N�meros\t||");
	printf("\n\t||3.Ingrese N�meros Para los C�lculos\t||");
	printf("\n\t||4.Eliminar N�meros\t\t\t||");	
	printf("\n\t||5.Mostrar N�meros En Cola\t\t||");
	printf("\n\t||6.Guardar Datos\t\t\t||");
	printf("\n\t\t\tSeleccione: ");
	scanf("%d",&eleccion);
	system("cls");
	printf("Usted seleccion� la Opcion %d\n\n",eleccion);
	switch(eleccion){
		case 1:
			explicacionSuma();
			break;
		case 2:
			explicacionResta();
			break;
		case 3:
			ingresarDatosRegistro();
			break;
		case 4:
			eliminarNumeros();
			break;
		case 5:
			mostrarCola();
			break;		
		case 6:
			grabarRegistroParticipante();
			break;	
	}
}

void explicacionSuma(){
	printf("\n\tLlamamos suma a la acci�n de a�adir, juntar o agregar elementos,\n\tcuando realizamos esta acci�n estamos uniendo cantidades o conjuntos \n\ty para ello siempre debe haber un m�nimo de dos elementos.\n\n");
}

void explicacionResta(){
	printf("\n\tLa resta o sustracci�n es una operaci�n matem�tica que consiste en sacar, quitar,\n\treducir o separar algo de un todo. Restar es una de las \n\toperaciones b�sicas de las matem�ticas junto a la suma, que es su proceso inverso.\n\n");
}

bool colaVacia(tr_jugadores vr_jugadores){
	return(vr_jugadores.frente==-1 && vr_jugadores.final==-1);
}

bool colaLlena(tr_jugadores vr_jugadores){
	return(vr_jugadores.final==(NUMEROS-1));
}

void ingresarDatosRegistro(){  
		printf("Ingrese numero A: ");
		scanf("%f",&num1);	
		printf("Ingrese numero B: ");
		scanf("%f",&num2);
	colaDeNumeros(num1,num2);	
}
	
void colaDeNumeros(float pNum1,float pNum2){
	int i;
	if(colaLlena(vr_jugadores)){
		printf("No se puede seguir realizar el push");
	}
	else{
		vr_jugadores.final+=1;
		vr_jugadores.calculos1[vr_jugadores.final]=pNum1;
		vr_jugadores.calculos2[vr_jugadores.final]=pNum2;
		
		if(vr_jugadores.final==0){
			vr_jugadores.frente=0;
		}
	}
}

void eliminarNumeros(){
	float numEliminar1,numEliminar2;
	int i;
	if(colaVacia(vr_jugadores)){
		printf("\n\tNo hay N�meros para eliminar...\n");
	}
	else{
		numEliminar1=vr_jugadores.calculos1[vr_jugadores.frente];
		numEliminar2=vr_jugadores.calculos2[vr_jugadores.frente];
		
		vr_jugadores.calculos1[vr_jugadores.frente]=0;
		vr_jugadores.calculos2[vr_jugadores.frente]=0;
		
		if(vr_jugadores.frente==vr_jugadores.final){
			inicializarCola();
		}
		else{
			vr_jugadores.frente+=1;
		}
		
		printf("\n\tN�meros Eliminados: %.2f %.2f",numEliminar1,numEliminar2);
	}
}

void mostrarCola(){
	if(colaVacia(vr_jugadores)){
		printf("\n\tNo hay numeros a mostrar");
	}
	else{
		printf("\n\tN�meros: \n");
		int i;
		for(i=vr_jugadores.frente;i<=vr_jugadores.final;i++){
			printf("\t| %.2f_%.2f \t|\n ",vr_jugadores.calculos1[i],vr_jugadores.calculos2[i]);
		}
	}	
}

void grabarRegistroParticipante() {
/* Se graba 1 registro en el archivo del Cliente */
	fwrite( &vr_jugadores, sizeof( tr_jugadores ), 1, vf_jugadores);
	printf( "\tRegistro del Participante insertado! \n" );
	moduloAbarcador();
}

void finalizarProceso() {
	fclose(vf_jugadores);
}
